﻿<head>
    <meta charset="UTF-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>CREATE</title>
</head>
<form action='download_test.php'>
	<button>다운로드</button>
</form>
<form action='download_ok.php'>
	<button>다운로드 two</button>
</form>