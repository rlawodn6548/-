﻿<head>
    <meta charset="UTF-8">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>CREATE</title>
</head>
<form enctype='multipart/form-data' action='upload_ok.php' method='post'>
	<input type='file' name='myfile'>
	<button>업로드</button>
</form>